import React, { useState } from "react";
import { motion } from "framer-motion";
import useSound from 'use-sound';
import successSfx from './sounds/success.mp3';

const shapes = [
  { id: 1, name: "Circle", color: "bg-red-400", shape: "rounded-full" },
  { id: 2, name: "Square", color: "bg-blue-400", shape: "" },
  { id: 3, name: "Triangle", color: "bg-green-400", shape: "clip-triangle" },
];

export default function ShapeMatcher() {
  const [matched, setMatched] = useState([]);
  const [playSuccess] = useSound(successSfx);

  const handleDrop = (id) => {
    if (!matched.includes(id)) {
      setMatched([...matched, id]);
      playSuccess();
    }
  };

  return (
    <div className="min-h-screen bg-yellow-50 p-8">
      <h1 className="text-4xl font-bold text-center mb-8 text-purple-600 animate-bounce">Shape Matcher</h1>
      <div className="grid grid-cols-2 gap-8">
        <div>
          <h2 className="text-2xl mb-4">Drag the Shapes</h2>
          <div className="flex gap-4 flex-wrap">
            {shapes.map((shape) => (
              !matched.includes(shape.id) && (
                <motion.div
                  key={shape.id}
                  drag
                  dragConstraints={{ left: 0, top: 0, right: 300, bottom: 300 }}
                  whileDrag={{ scale: 1.2 }}
                  className={`w-24 h-24 cursor-pointer shadow-lg ${shape.color} ${shape.shape}`}
                />
              )
            ))}
          </div>
        </div>

        <div>
          <h2 className="text-2xl mb-4">Match the Shapes</h2>
          <div className="flex gap-4 flex-wrap">
            {shapes.map((shape) => (
              <div
                key={shape.id}
                onDragOver={(e) => e.preventDefault()}
                onDrop={() => handleDrop(shape.id)}
                className={`w-24 h-24 border-4 border-dashed border-gray-400 flex items-center justify-center ${shape.shape}`}
              >
                {matched.includes(shape.id) ? (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: 'spring', stiffness: 200 }}
                    className={`w-16 h-16 ${shape.color} ${shape.shape}`}
                  />
                ) : (
                  <span className="text-sm text-gray-500 text-center">Drop\n{shape.name}</span>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

const style = document.createElement('style');
style.innerHTML = `
.clip-triangle {
  width: 0;
  height: 0;
  border-left: 48px solid transparent;
  border-right: 48px solid transparent;
  border-bottom: 96px solid #34D399;
  background: none;
}
`;
document.head.appendChild(style);
